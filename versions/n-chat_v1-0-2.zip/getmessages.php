<?php
	/*
	N-Chat
	(C)2019 crispycat (Nikotek)
	*/

	require "init.php";

	if (! ($_SESSION["authed"] && isset($_GET["conv"]) && $_GET["conv"] != "")) {
		die("Unauthorized or invalid query.");
	}

	$q = "SELECT * FROM conversations WHERE id = '".$_GET["conv"]."' AND users LIKE '%".$_SESSION["user"]."%'";
	if (mysqli_num_rows(mysqli_query($dbc, $q)) > 0 || $_GET["conv"] == "0") {
		$q = "SELECT * FROM messages WHERE conversation = '".$_GET["conv"]."'";
		$r = mysqli_query($dbc, $q);
		if (mysqli_num_rows($r) > 0) {
			header("Content-type: text/json");
			echo "[\n";
			while ($row = mysqli_fetch_assoc($r)) {
				echo "{\n";
				echo "\"id\": \"".$row["id"]."\",\n";
				echo "\"conversation\": \"".$row["conversation"]."\",\n";
				echo "\"sentby\": \"".$row["sentby"]."\",\n";
				echo "\"time\": \"".$row["time"]."\",\n";
				echo "\"content\": \"".$row["content"]."\",\n";
				echo "\"attachments\": \"".$row["attachments"]."\"\n";
				echo "},\n";
			}
			echo "{}]";
		} else {
			die("No messages.");
		}
	} else {
		die("Unauthorized.");
	}
?>
