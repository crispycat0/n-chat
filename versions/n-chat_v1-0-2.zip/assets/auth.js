function Auth() {
	var xhr = new XMLHttpRequest();
	xhr.open("POST", "auth.php", true);
	xhr.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			console.log(this.responseText);
			if (this.responseText == "OK") {
				location.href = "app.php";
			} else {
				$("#auth-error").html(this.responseText);
				$("#auth-error").toggleClass("text-danger", true);
			}
		}
	}
	xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xhr.send("login=login&user=" + $("#auth-user").val() + "&pass=" + $("#auth-pass").val());
}
