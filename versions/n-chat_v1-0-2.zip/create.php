<?php
	/*
	N-Chat
	(C)2019 crispycat (Nikotek)
	*/

	require "init.php";

	if (! ($_SESSION["authed"] && isset($_GET["users"]) && $_GET["users"] != "")) {
		die("Unauthorized or invalid query.");
	}

	$q = "INSERT INTO conversations (id, users) VALUES ('".mysqli_num_rows(mysqli_query($dbc, "SELECT * FROM conversations"))."', '".$_GET["users"]."')";
	die(mysqli_query($dbc, $q));
?>
