<?php
	/*
	N-Chat
	(C)2019 crispycat (Nikotek)
	*/
?>
<link rel="stylesheet" href="<?php echo ASSETS_PATH; ?>/bootstrap.css" />
<link rel="stylesheet" href="<?php echo ASSETS_PATH; ?>/nchcss.css" />
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,300i,400,400i,700,700i" />
<link rel="favicon" href="<?php echo ASSETS_PATH; ?>/favicon.ico" />
<link rel="icon" href="<?php echo ASSETS_PATH; ?>/favicon.ico" />
<link rel="shortcut icon" href="<?php echo ASSETS_PATH; ?>/favicon.ico" />
<script src="<?php echo ASSETS_PATH; ?>/jq331.js"></script>
<script src="<?php echo ASSETS_PATH; ?>/bootstrap.js"></script>
