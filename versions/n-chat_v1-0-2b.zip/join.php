<?php
	/*
	N-Chat
	(C)2019 crispycat (Nikotek)
	*/

	require "init.php";

	if (! ($_SESSION["authed"] && isset($_GET["conv"]) && $_GET["conv"] != "")) {
		die("Unauthorized or invalid query.");
	}

	if ((int) $_GET["conv"] < 1) {
		die("Invalid query.");
	}

	$q = "SELECT * FROM conversations WHERE id = '".$_GET["conv"]."'";
	$res = mysqli_query($dbc, $q);
	if (mysqli_num_rows($res) < 1) {
		die("Invalid ID.");
	} else {
		while ($row = mysqli_fetch_assoc($res)) {
			$q = "UPDATE conversations SET users = '".$row["users"].",".$_SESSION["user"]."' WHERE id = '".$_GET["conv"]."'";
			$res = mysqli_query($dbc, $q);
			if ($res === true) {
				die("OK");
			}
		}
	}
?>
