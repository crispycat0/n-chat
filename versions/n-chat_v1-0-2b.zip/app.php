<?php
	/*
	N-Chat
	(C)2019 crispycat (Nikotek)
	*/

	require "init.php";
	if (isset($_GET["m"])) {

	}
?>
<!DOCTYPE html>
<html>
	<head>
		<title>N-Chat</title>
		<?php require "loadassets.php"; ?>
		<script src="<?php echo ASSETS_PATH; ?>/nchat.js"></script>
	</head>
	<body>
		<noscript><span class="text-danger">Please enable JavaScript or N-Chat won't work!!</span></noscript>
		<div class="modal fade" id="create-conv" tabindex="-1" role="dialog">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header bg-success">
						<h5 class="modal-title text-white">Create conversation</h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<div class="modal-body">
						<form>
							<label>Users:</label>
							<input type="text" class="form-control" id="create-conv-users" />
							<small>A list of users separated by a comma (e. g. <code>crispycat,crunchydog</code>)</small>
						</form>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-success" onclick="CreateConversation()">Create</button>
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
					</div>
				</div>
			</div>
		</div>
		<div class="modal fade" id="join-conv" tabindex="1" role="dialog">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header bg-success">
						<h5 class="modal-title text-white">Join conversation</h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<div class="modal-body">
						<form>
							<label>ID:</label>
							<input type="number" class="form-control" id="join-conv-id" />
							<small>(e. g. <code>1337</code>)</small>
							<small id="join-conv-error" class="text-danger"></small>
						</form>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-success" onclick="JoinConversation()">Join</button>
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
					</div>
				</div>
			</div>
		</div>
		<div class="modal fade" id="leave-conv" tabindex="-1" role="dialog">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header bg-danger">
						<h5 class="modal-title text-light">Leave conversation</h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<div class="modal-body">
						<p>Are you sure you want to leave this conversation?</p>
						<small id="leave-conv-error" class="text-danger"></small>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-danger" onclick="LeaveCurrentConversation()">Leave</button>
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
					</div>
				</div>
			</div>
		</div>
		<div class="container-fluid">
			<nav id="topbar" class="navbar navbar-expand-md">
				<a class="navbar-brand" href="<?php echo APPLICATION_PATH; ?>"><img src="<?php echo ASSETS_PATH; ?>/title.gif" alt="N-Chat" /></a>
				<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#topbar-nav" style="margin-right: -12px;">
					<img src="<?php echo ASSETS_PATH; ?>/hamburger.png"></img>
				</button>
				<div id="topbar-nav" class="collapse navbar-collapse">
					<ul class="navbar-nav ml-auto">
						<li class="nav-item">
							<a class="nav-link text-success" href="#" onclick="$('#create-conv').modal('show'); $('#topbar-nav').collapse('hide');">New conversation</a>
						</li>
						<li class="nav-item">
							<a class="nav-link text-success" href="#" onclick="$('#join-conv').modal('show'); $('#topbar-nav').collapse('hide');">Join conversation</a>
						</li>
						<li class="nav-item">
							<a class="nav-link text-danger" href="#" onclick="$('#leave-conv').modal('show'); $('#topbar-nav').collapse('hide');">Leave conversation</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="#" onclick="ToggleAutoScroll(); $('#topbar-nav').collapse('hide');">Auto scroll: <span id="as_indicator" class="badge badge-success">On</span></a>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="https://www.nikotek.net/#contact">I found a bug</a>
						</li>
						<li class="nav-item">
							<a class="btn btn-danger" href="auth.php?logout">Log out</a>
						</li>
					</ul>
					<form class="form-inline d-none" action="">
						<!-- ADD THIS AT A LATER DATE -->
						<input type="text" class="form-control ml-md-2" id="searchbox" placeholder="Search messages" onkeyup="Search()" />
					</form>
				</div>
			</nav>
			<div id="main" class="row">
				<div id="sidebar" class="col-xl-3 col-md-4">
					<div class="row">
						<div class="col-12">
							<div id="user-info">
								<span class="text-muted display-4 text-center d-block">@<?php echo $_SESSION["user"]; ?></span>
								<span class="text-muted text-center d-block clock"></span>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-12">
							<div id="conversations">

							</div>
						</div>
					</div>
				</div>
				<div id="chat" class="col-xl-9 col-md-8">
					<div class="row">
						<div class="col-12">
							<div id="messages">

							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-12">
							<div id="send-form">
								<form>
									<textarea class="form-control" id="msgbox" placeholder="Type your message..." onkeyup="CheckText()"></textarea>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</body>
</html>
