<?php
	/*
	N-Chat
	(C)2019 crispycat (Nikotek)
	*/

	// CONFIG
	def("APPLICATION_PATH", "//".$_SERVER["HTTP_HOST"].dirname($_SERVER["REQUEST_URI"]));
	def("ASSETS_PATH", APPLICATION_PATH."/assets");
	def("DB", "n_chat");
	def("AUTH_DB", "nikotek");
	def("DB_HOST", "localhost");
	def("DB_USER", "nikotek");
	def("DB_AUTH", "");
	def("LOGIN_SALT", "$2a$09$13373cb51d02ba09yeetc7128$");
	// END CONFIG
?>
