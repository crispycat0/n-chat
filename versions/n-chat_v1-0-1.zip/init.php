<?php
	/*
	N-Chat
	(C)2019 crispycat (Nikotek)
	*/

	function def($var, $data) {
		if (!defined($var)) define($var, $data);
	}

	require "config.php";

	// Finish up
	$dbc = new mysqli(DB_HOST, DB_USER, DB_AUTH, DB);
	if ($dbc -> connect_error && ! isset($_GET["e"])) {
		die("<center><strong><h1>Uh oh! N-Chat is not working right now. Please try again later.</h1></strong></center>");
	}

	session_start();
	if (! $_SESSION["authed"]) {
		header("Location: auth.php");
	}
?>
