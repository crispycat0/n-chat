<?php
	/*
	N-Chat
	(C)2019 crispycat (Nikotek)
	*/

	require "init.php";

	if (! ($_SESSION["authed"] && isset($_POST["conv"]) && $_POST["conv"] != "" && isset($_POST["msg"]) && $_POST["msg"] != "")) {
		die("Unauthorized or invalid query.");
	}

	$q = "SELECT * FROM conversations WHERE id = '".$_POST["conv"]."' AND users LIKE '%".$_SESSION["user"]."%'";
	if (mysqli_num_rows(mysqli_query($dbc, $q)) > 0 || $_POST["conv"] == "0") {
		$msg = mysqli_real_escape_string($dbc, $_POST["msg"]);
		$msg = str_replace("<", "&lt;", $msg);
		$msg = str_replace(">", "&gt;", $msg);
		$msg = str_replace("'", "&apos;", $msg);
		$msg = str_replace("\"", "&quot;", $msg);
		$msg = str_replace("&", "&amp;", $msg);
		$msg = str_replace("\r\n", "<br />", $msg);
		$msg = str_replace("\n", "<br />", $msg);
		$msg = str_replace("\r", "<br />", $msg);
		$msg = str_replace("\\r\\n", "<br />", $msg);
		$msg = str_replace("\\n", "<br />", $msg);
		$msg = str_replace("\\r", "<br />", $msg);
		$q = "INSERT INTO messages (id, conversation, sentby, time, content, attachments) VALUES ('".mysqli_num_rows(mysqli_query($dbc, 'SELECT * FROM messages'))."', '".$_POST["conv"]."', '".$_SESSION["user"]."', '".time()."', '".$msg."', '')";
		$r = mysqli_query($dbc, $q);
		die(printf($r, true).$msg);
	} else {
		die("Unauthorized.");
	}
?>
