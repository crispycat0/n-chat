var conv = 0;
var AutoScroll = true;

function fixtime(t) {
	function addzeros(n) {
		if (n < 10) {
			n = "0" + n;
		}
		return n;
	}
	var date = new Date(t * 1000);
	return date.getFullYear() + "-" + addzeros(date.getMonth() + 1) + "-" + addzeros(date.getDate()) + " " + addzeros(date.getHours()) + ":" + addzeros(date.getMinutes()) + ":" + addzeros(date.getSeconds());
}

function GetMessages(c) {
	var mxhr = new XMLHttpRequest();
	mxhr.open("GET", "getmessages.php?conv=" + c, true);
	mxhr.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			$("#messages").html("");
			var res = JSON.parse(this.responseText);
			console.log(res);
			for (i = 0; i < res.length - 1; i++) {
				$("#messages").html($("#messages").html() + "<div id='msg-" + res[i].id + "'>" +
				"<hr />" +
				"<small>" + res[i].sentby + " at " + fixtime(res[i].time) + "&nbsp;&bull;&nbsp;<a href='#' onclick='CopyMessage(" + res[i].id + ")'>Copy</a></small>" +
				"<p>" + res[i].content + "</p>" +
				"</div>");
			}
			if (AutoScroll) {
				var box = document.getElementById("messages");
				box.scrollTop = box.scrollHeight;
			}
		}
	};
	mxhr.send();
}

function GetConversations() {
	var cxhr = new XMLHttpRequest();
	cxhr.open("GET", "getconversations.php", true);
	cxhr.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			var res = JSON.parse(this.responseText);
			console.log(res);
			$("#conversations").html("");
			for (i = 0; i < res.length - 1; i++) {
				$("#conversations").html($("#conversations").html() + "<div id='conv-" + res[i].id + "'>" +
				"<hr />" +
				"<a href='#' class='d-block' onclick='SwitchConversation(" + res[i].id + ")'>" + res[i].users + "</a>" +
				"<small class='text-muted'>ID: "+ res[i].id + "</small>" +
				"</div>");
			}
		}
	};
	cxhr.send();
}

function SendMessage(c, m) {
	var xhr = new XMLHttpRequest();
	xhr.open("POST","send.php", true);
	xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xhr.onreadystatechange = function() {
		if (this.readyState == 4) {
			console.log(this.responseText);
			GetMessages(conv);
		}
	}
	xhr.send("conv=" + c + "&msg=" + m);
}

function ToggleAutoScroll() {
	AutoScroll = !AutoScroll;
	$("#as_indicator").toggleClass("badge-success");
	$("#as_indicator").toggleClass("badge-secondary");
	(AutoScroll) ? $("#as_indicator").html("On") : $("#as_indicator").html("Off");
}

function SwitchConversation(c) {
	console.log("Switching to" + c);
	conv = c;
	console.log(c + " == " + conv + "?");
	GetMessages(conv);
}

function CopyMessage(m) {
	if (document.selection) {
		var range = document.body.createTextRange();
		range.moveToElementText(document.getElementById("msg-" + m));
		range.select().createTextRange();
	} else {
		var range = document.createRange();
		range.selectNode(document.getElementById("msg-" + m));
		window.getSelection().addRange(range)
	}
	document.execCommand('copy');
	$("#msg-" + m).toggleClass("bg-primary");
	setTimeout(function() { $("#msg-" + m).toggleClass("bg-primary"); }, 300);
}

/*
function Search() {
	function highlight(text) {
		var sobj = $("#messages").html()
		var index = sobj.indexOf(text);
		if (index >= 0) {
			$("#messages").html(sobj.substring(0,index) + "<span class='highlight'>" + sobj.substring(index,index+text.length) + "</span>" + sobj.substring(index + text.length));
		}
	}

	highlight($("searchbox").val())
}
*/

function CreateConversation() {
	var vxhr = new XMLHttpRequest();
	vxhr.open("GET", "create.php?users=" + $("#create-conv-users").val(), true);
	vxhr.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			console.log(this.responseText);
			location.reload();
		}
	}
	vxhr.send();
}

function JoinConversation() {
	var jxhr = new XMLHttpRequest();
	jxhr.open("GET", "join.php?conv=" + $("#join-conv-id").val(), true);
	jxhr.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			console.log(this.responseText);
			if (this.responseText == "OK") {
				location.reload();
			} else {
				$("#join-conv-error").html("ERROR: " + this.responseText);
			}
		}
	}
	jxhr.send();
}

function LeaveCurrentConversation() {
	var lxhr = new XMLHttpRequest();
	lxhr.open("GET", "leave.php?conv=" + conv, true);
	lxhr.onreadystatechange = function() {
		console.log(this.responseText);
		if (this.responseText == "OK") {
			location.reload();
		} else {
			$("#leave-conv-error").html("ERROR: " + this.responseText);
		}
	}
	lxhr.send();
}

function CheckText() {
	if ($("#msgbox").val().indexOf("\n") > -1) {
		SendMessage(conv, $("#msgbox").val());
		$("#msgbox").val("");
	}
}

GetConversations();
GetMessages(conv);
setInterval(function() { GetMessages(conv); }, 2000);
setInterval(GetConversations, 10000);
