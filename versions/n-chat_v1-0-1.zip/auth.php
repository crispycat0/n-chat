<?php
	/*
	N-Chat
	(C)2019 crispycat (Nikotek)
	*/
	function def($var, $data) {
		if (!defined($var)) define($var, $data);
	}
	require "config.php";

	$dbc = new mysqli(DB_HOST, DB_USER, DB_AUTH, AUTH_DB);
	if ($dbc -> connect_error && ! isset($_GET["e"])) {
		die("<center><strong><h1>Uh oh! N-Chat is not working right now. Please try again later.</h1></strong></center>");
	}

	$salt = LOGIN_SALT;

	session_start();

	if (isset($_GET["logout"])) {
		$_SESSION = [];
		session_destroy();
		session_unset();
		header("Location: auth.php");
	}

	if (isset($_SESSION["authed"]) && $_SESSION["authed"]) {
		header("Location: app.php");
	}

	if (isset($_POST["login"])) {
		// Check all info is there
		if ((! isset($_POST["user"])) || (! isset($_POST["pass"]))) {
			die("Username and password required");
		}

		// Attempt log in
		$q = "SELECT * FROM accounts WHERE user = '".strtolower($_POST["user"])."' AND pass = '".crypt($_POST["pass"], $salt)."'";
		$res = mysqli_query($dbc, $q);
		if (mysqli_num_rows($res) == 1) {
			$row = mysqli_fetch_row($res);
			$q = "UPDATE accounts SET time = '".$t."' WHERE user = '".$row[0]."'";
			$res = mysqli_query($dbc, $q);
			if (! $res) {
				die("Could not update time");
			}
			$q = "UPDATE accounts SET ip = '".$_SERVER["REMOTE_ADDR"]."' WHERE user = '".$row[0]."'";
			$res = mysqli_query($dbc, $q);
			if (! $res) {
				die("Could not update IP");
			}
			$_SESSION["authed"] = true;
			$_SESSION["user"] = $row[0];
			$_SESSION["email"] = $row[2];
			$_SESSION["nick"] = $row[3];
			$_SESSION["ip"] = $_SERVER["REMOTE_ADDR"];
			$_SESSION["time"] = $t;
			header("Location: app.php");
		} else {
			die("Incorrect username or password");
		}
	}
?>
<!DOCTYPE html>
<html>
	<head>
		<title>N-Chat</title>
		<?php require "loadassets.php"; ?>
	</head>
	<body>
		<noscript><span class="text-danger">Please enable JavaScript or N-Chat won't work!!</span></noscript>
		<div class="modal fade" id="about" tabindex="-1" role="dialog">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header bg-primary">
						<h5 class="modal-title text-white">About N-Chat</h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<div class="modal-body">
						<p>N-Chat is a simple web chat application. It is made with PHP and JavaScript. You can create or join a conversation and chat with other users.</p>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-primary" data-dismiss="modal" aria-label="Close">Got it</button>
					</div>
				</div>
			</div>
		</div>
		<div class="container">
			<div class="row">
				<div class="col-12">
					<div id="auth-form">
						<img src="<?php echo ASSETS_PATH; ?>/title.gif" alt="N-chat" />
						<small>Please log in with your Nikotek account.</small>
						<form method="post">
							<div class="form-group">
								<input type="text" class="form-control mx-2 my-3" name="user" placeholder="Username" />
							</div>
							<div class="form-group">
								<input type="password" class="form-control mx-2 my-3" name="pass" placeholder="Password" />
							</div>
							<input type="hidden" name="login" />
							<input type="submit" class="btn btn-primary mx-2 my-3" value="Log in" />
							<a href="//www.nikotek.net/account/login.php">Sign up</a>
							<a href="#" onclick="$('#about').modal('show')">About N-Chat</a>
						</form>
					</div>
				</div>
			</div>
		</div>
	</body>
</html>
