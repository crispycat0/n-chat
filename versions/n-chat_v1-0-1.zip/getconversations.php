<?php
	/*
	N-Chat
	(C)2019 crispycat (Nikotek)
	*/

	require "init.php";

	if (! $_SESSION["authed"]) {
		die("Unauthorized.");
	}

	header("Content-type: text/json");
	echo "[\n";
	echo "{\n";
	echo "\"id\": \"0\",\n";
	echo "\"users\": \"Everyone\"\n";
	echo "},\n";
	$q = "SELECT * FROM conversations WHERE users LIKE '%".$_SESSION["user"]."%'";
	$r = mysqli_query($dbc, $q);
	if (mysqli_num_rows(mysqli_query($dbc, $q)) > 0) {
		while ($row = mysqli_fetch_assoc($r)) {
			echo "{\n";
			echo "\"id\": \"".$row["id"]."\",\n";
			echo "\"users\": \"".$row["users"]."\"\n";
			echo "},\n";
		}
	}
	echo "{}]";
?>
